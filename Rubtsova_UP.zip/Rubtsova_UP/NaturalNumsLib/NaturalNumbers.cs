﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NaturalNumsLib
{
    public static class NaturalNumbers
    {
        public static bool IsEven(int Number)
        {
            return Number % 2 == 0;
        }

        public static int GCD(int A, int B) // greatest common divisor (GCD)
        {
            int NOD = -1;
            if (A != 0 && B != 0)
            {
                if (A > B)
                {
                    for (int i = 1; i <= B; i++)
                    {
                        if (A % i == 0 && B % i == 0)
                            NOD = i;
                    }
                    return NOD;
                }
                else
                {
                    for (int i = 1; i <= A; i++)
                    {
                        if (A % i == 0 && B % i == 0)
                            NOD = i;
                    }
                    return NOD;
                }
            }
            else return A + B;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Number"></param>
        /// <returns></returns>
        public static bool IsPrime(int Number)
        {
            if (!(Number <= 0) && !(Number ==1))
            {
                for (int i = 2; i < Number; i++)
                {
                    if (Number % i == 0)
                    {
                        return false;
                    }
                }
                return true;
            }
            else
                return false;
        }

        public static int LCM(int A, int B)
        {
            int LCM = -1;
            if (A != 0 && B != 0)
            {
                if (A > B)
                {
                    for (int i = B; i >= 1; i--)
                    {
                        if (A % i == 0 && B % i == 0)
                            LCM = i;
                    }
                    return LCM;
                }
                else
                {
                    for (int i = A; i >= 1; i--)
                    {
                        if (A % i == 0 && B % i == 0)
                            LCM = i;
                    }
                    return LCM;
                }
            }
            else return A + B;
        }
    }
}
