﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using Rubtsova_zad4;
using System.IO;


namespace Test_zad4
{
    [TestClass]
    public class UnitTest1
    {
        private const string InputFilePath = "input.txt";
        private const string OutputFilePath = "output.txt";

        private void WriteInputFile(string content)
        {
            File.WriteAllText(InputFilePath, content);
        }

        private string ReadOutputFile()
        {
            return File.ReadAllText(OutputFilePath);
        }

        [TestMethod]
        public void Test_CorrectCostWithTwoBoards()
        {
            WriteInputFile("2\n1 2");
            Program.Main();
            Assert.AreEqual("2", ReadOutputFile()); // 1 + 2
        }

        [TestMethod]
        public void Test_CorrectCostWithAllSameTime()
        {
            WriteInputFile("5\n2 2 2 2 2");
            Program.Main();
            Assert.AreEqual("6", ReadOutputFile()); // 2 + max(2, 2) + max(2, 2) = 6
        }

        [TestMethod]
        public void Test_CorrectCostWithOneBoard()
        {
            WriteInputFile("1\n5");
            Program.Main();
            Assert.AreEqual("5", ReadOutputFile()); // Только одна доска
        }

        [TestMethod]
        public void Test_CorrectCostWithMaxBoards()
        {
            WriteInputFile("10000\n" + string.Join(" ", Enumerable.Repeat("1", 10000)));
            Program.Main();
            Assert.AreEqual("5000", ReadOutputFile()); // 1 + 1 + ... (5000 раз)
        }

        [TestMethod]
        public void Test_EmptyFile()
        {
            WriteInputFile("");
            Program.Main();
            Assert.AreEqual("Ошибка: Файл пуст.", ReadOutputFile());
        }

        [TestMethod]
        public void Test_NegativeBoardCount()
        {
            WriteInputFile("-1\n1 2");
            Program.Main();
            Assert.AreEqual("Ошибка: Некорректное количество досок.", ReadOutputFile());
        }

        [TestMethod]
        public void Test_ZeroBoardCount()
        {
            WriteInputFile("0\n");
            Program.Main();
            Assert.AreEqual("Ошибка: Некорректное количество досок.", ReadOutputFile());
        }

        [TestMethod]
        public void Test_NonIntegerBoardCount()
        {
            WriteInputFile("abc\n1 2");
            Program.Main();
            Assert.AreEqual("Ошибка: Некорректное количество досок.", ReadOutputFile());
        }

        [TestMethod]
        public void Test_MissingPaintingTimes()
        {
            WriteInputFile("2\n");
            Program.Main();
            Assert.AreEqual("Ошибка: Отсутствуют данные о времени покраски.", ReadOutputFile());
        }

        [TestMethod]
        public void Test_TooManyPaintingTimes()
        {
            WriteInputFile("2\n1 2 3");
            Program.Main();
            Assert.AreEqual("Ошибка: Количество времён не соответствует количеству досок.", ReadOutputFile());
        }

        [TestMethod]
        public void Test_NonIntegerPaintingTime()
        {
            WriteInputFile("2\n1 abc");
            Program.Main();
            Assert.AreEqual("Ошибка: Некорректные данные о времени покраски.", ReadOutputFile());
        }

        [TestMethod]
        public void Test_ZeroPaintingTime()
        {
            WriteInputFile("2\n0 0");
            Program.Main();
            Assert.AreEqual("0", ReadOutputFile()); // 0 + 0
        }

        [TestMethod]
        public void Test_CorrectCostWithMixedValues()
        {
            WriteInputFile("6\n1 100 1 100 1 100");
            Program.Main();
            Assert.AreEqual("300", ReadOutputFile()); // 1 + max(100, 1) + max(100, 1) + max(100, 1)
        }

        [TestMethod]
        public void Test_CorrectCostWithAllZeros()
        {
            WriteInputFile("5\n0 0 0 0 0");
            Program.Main();
            Assert.AreEqual("0", ReadOutputFile()); // Все нули
        }

        [TestMethod]
        public void Test_CorrectCostWithTwoBoardsSameTime()
        {
            WriteInputFile("2\n5 5");
            Program.Main();
            Assert.AreEqual("5", ReadOutputFile()); // 5 + max(5, 5)
        }
      
        [TestMethod]
        public void Test_CorrectCostWithMaxBoardCount()
        {
            WriteInputFile("10000\n" + string.Join(" ", Enumerable.Repeat("1", 10000)));
            Program.Main();
            Assert.AreEqual("5000", ReadOutputFile()); // 1 + 1 + ... (5000 раз)
        }
        [TestMethod]
        public void Test_CorrectCostWithAlternatingFastSlow()
        {
            WriteInputFile("6\n1 100 1 100 1 100");
            Program.Main();
            Assert.AreEqual("300", ReadOutputFile()); // 1 + 100 + 1 + 100 + 1 + 100
        }

      
        [TestMethod]
        public void Test_CorrectCostWithSingleHighValue()
        {
            WriteInputFile("1\n100000");
            Program.Main();
            Assert.AreEqual("100000", ReadOutputFile()); // Только одна доска
        }

        [TestMethod]
        public void Test_CorrectCostWithEdgeCaseMinimumTime()
        {
            WriteInputFile("2\n1 0");
            Program.Main();
            Assert.AreEqual("1", ReadOutputFile()); // 1 + max(1, 0)
        }

        [TestMethod]
        public void Test_CorrectCostWithEdgeCaseZeroTime()
        {
            WriteInputFile("2\n0 0");
            Program.Main();
            Assert.AreEqual("0", ReadOutputFile()); // 0 + max(0, 0)
        }

        [TestMethod]
        public void Test_CorrectCostWithAlternatingHighLow()
        {
            WriteInputFile("8\n1 100 1 100 1 100 1 100");
            Program.Main();
            Assert.AreEqual("400", ReadOutputFile()); // 1 + 100 + 1 + 100 + 1 + 100 + 1 + 100
        }

     
    }
}
