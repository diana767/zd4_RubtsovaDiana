﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace Rubtsova_zad4
{
    static public class Program
    {
        static public void Main()
        {
            string inputFilePath = "input.txt";
            string outputFilePath = "output.txt";

            // Проверка на существование файла
            if (!File.Exists(inputFilePath))
            {
                File.WriteAllText(outputFilePath, "Ошибка: Файл не найден.");
                return;
            }

            // Чтение входных данных из файла
            string[] inputLines = File.ReadAllLines(inputFilePath);

            // Проверка на пустоту файла
            if (inputLines.Length == 0 || string.IsNullOrWhiteSpace(inputLines[0]))
            {
                File.WriteAllText(outputFilePath, "Ошибка: Файл пуст.");
                return;
            }

            // Проверка на корректность количества досок
            if (!int.TryParse(inputLines[0], out int n) || n < 1 || n > 10000)
            {
                File.WriteAllText(outputFilePath, "Ошибка: Некорректное количество досок.");
                return;
            }

            // Проверка на наличие данных о времени покраски
            if (inputLines.Length < 2 || string.IsNullOrWhiteSpace(inputLines[1]))
            {
                File.WriteAllText(outputFilePath, "Ошибка: Отсутствуют данные о времени покраски.");
                return;
            }

            // Чтение времён покраски
            int[] t;
            try
            {
                t = Array.ConvertAll(inputLines[1].Split(' '), int.Parse);
            }
            catch (FormatException)
            {
                File.WriteAllText(outputFilePath, "Ошибка: Некорректные данные о времени покраски.");
                return;
            }

            // Проверка на соответствие количества времён количеству досок
            if (t.Length != n)
            {
                File.WriteAllText(outputFilePath, "Ошибка: Количество времён не соответствует количеству досок.");
                return;
            }

            // Массив для хранения минимального времени покраски
            int[] dp = new int[n];

            // Базовые случаи
            dp[0] = t[0];
            if (n > 1)
            {
                dp[1] = Math.Max(t[0], t[1]);
            }

            // Заполнение массива dp
            for (int i = 2; i < n; i++)
            {
                // Вариант 1: покрасить i-ю доску отдельно
                dp[i] = dp[i - 1] + t[i];

                // Вариант 2: покрасить i-ю и (i-1)-ю доски вместе
                dp[i] = Math.Min(dp[i], dp[i - 2] + Math.Max(t[i - 1], t[i]));
            }

            // Записываем результат в файл
            File.WriteAllText(outputFilePath, dp[n - 1].ToString());
        }
       
    }
}
